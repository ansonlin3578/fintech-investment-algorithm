Library:
	1.pandas 
	2.numpy 
	3.glob
	4.matplotlib.pyplot 
	5.os
	6.mplfinance 
	7.python Version:3.6.8
	8.yfinance


Complier(Tool): Visual studio code

Notes:
	1.I use Visual studio code and matplotlib.pyplot,so it will plot the figure.Once the  
        figure appear, need to close the figure and let code countinue to run.
	2. I use the yfinance to catch the historic stock prices, so every time i'll redownload the
	stock price to calculate. 


